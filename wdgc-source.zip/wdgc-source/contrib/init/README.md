Sample configuration files for:

SystemD: wdgcd.service
Upstart: wdgcd.conf
OpenRC:  wdgcd.openrc
         wdgcd.openrcconf
CentOS:  wdgcd.init
OS X:    org.wdgc.wdgcd.plist

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.

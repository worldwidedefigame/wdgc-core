#!/bin/bash
# use testnet settings,  if you need mainnet,  use ~/.wdgccore/wdgcd.pid file instead
wdgc_pid=$(<~/.wdgccore/testnet3/wdgcd.pid)
sudo gdb -batch -ex "source debug.gdb" wdgcd ${wdgc_pid}

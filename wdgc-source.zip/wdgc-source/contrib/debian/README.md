
Debian
====================
This directory contains files used to package wdgcd/wdgc-qt
for Debian-based Linux systems. If you compile wdgcd/wdgc-qt yourself, there are some useful files here.

## wdgc: URI support ##


wdgc-qt.desktop  (Gnome / Open Desktop)
To install:

	sudo desktop-file-install wdgc-qt.desktop
	sudo update-desktop-database

If you build yourself, you will either need to modify the paths in
the .desktop file or copy or symlink your wdgc-qt binary to `/usr/bin`
and the `../../share/pixmaps/wdgc128.png` to `/usr/share/pixmaps`

wdgc-qt.protocol (KDE)


Building Wdgc
=============

See doc/build-*.md for instructions on building the various
elements of the Wdgc Core reference implementation of Wdgc.
